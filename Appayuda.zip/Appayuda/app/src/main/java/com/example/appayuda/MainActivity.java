package com.example.appayuda;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView; // Para los TextView
import android.location.Geocoder; // Para la dirección
import android.location.Address;   // Para la dirección
import java.util.List;          // Para la dirección
import java.util.Locale;        // Para la dirección
import java.io.IOException;     // Para el error del Geocoder
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import androidx.appcompat.app.AlertDialog; // O android.app.AlertDialog
import android.content.DialogInterface;
// Imports para ir a Ajustes (opcional pero recomendado)
import android.provider.Settings;
import android.net.Uri;
// Añade estas importaciones
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private EditText editTextNombre;
    private Button btnAyuda;

    private FirebaseFirestore db;

    private LocationManager locationManager;
    private static final int PERMISSION_REQUEST_CODE = 100; // Código para permisos
    private Handler locationTimeoutHandler = new Handler(Looper.getMainLooper());
    private Runnable locationTimeoutRunnable;
    private static final long LOCATION_TIMEOUT_MS = 5000; // 5 segundos de espera

    private TextView tvLatitud, tvLongitud, tvDireccion;
    private Geocoder geocoder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNombre = findViewById(R.id.editTextNombre);
        btnAyuda = findViewById(R.id.btnAyuda);
        db = FirebaseFirestore.getInstance();


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        tvLatitud = findViewById(R.id.tvLatitud);
        tvLongitud = findViewById(R.id.tvLongitud);
        tvDireccion = findViewById(R.id.tvDireccion);


        geocoder = new Geocoder(this, Locale.getDefault());


        btnAyuda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = editTextNombre.getText().toString();

                // Validación mínima
                if (nombre.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, ingresa un nombre.", Toast.LENGTH_SHORT).show();
                    return;
                } else if (nombre.length() <= 2) {
                    Toast.makeText(MainActivity.this, "El nombre debe contener mas de 2 caracteres como minimo", Toast.LENGTH_SHORT).show();
                    return;
                }

                tvLatitud.setText("Latitud: ...");
                tvLongitud.setText("Longitud: ...");
                tvDireccion.setText("Dirección: ...");
                // Iniciar el proceso de obtención de ubicación
                checkPermissionsAndGetLocation();
            }
        });
    }

    private void checkPermissionsAndGetLocation() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            startLocationProcess();

        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permiso de Ubicación Necesario")
                    .setMessage("Esta app necesita tu ubicación para registrar tu solicitud de ayuda. Por favor, concede el permiso para continuar.")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                                    PERMISSION_REQUEST_CODE);
                        }
                    })
                    .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(MainActivity.this, "No se puede enviar ayuda sin permiso de ubicación", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .create()
                    .show();

        } else {


            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                startLocationProcess();

            } else {

                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION) &&
                        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(this, "Permiso denegado permanentemente. Debes activarlo en los ajustes de la app.", Toast.LENGTH_LONG).show();


                    new AlertDialog.Builder(this)
                            .setTitle("Permiso Bloqueado")
                            .setMessage("Has denegado permanentemente el permiso de ubicación. Para usar esta función, debes activarlo manualmente en los Ajustes de la Aplicación.")
                            .setPositiveButton("Ir a Ajustes", (dialog, which) -> {

                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package", getPackageName(), null);
                                intent.setData(uri);
                                startActivity(intent);
                            })
                            .setNegativeButton("Cancelar", null)
                            .show();

                } else {

                    Toast.makeText(this, "El permiso de ubicación es necesario para enviar la alerta", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private void startLocationProcess() {
        boolean isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if (!isGpsEnabled && !isNetworkEnabled) {

            Toast.makeText(this, "Por favor, activa la Ubicación para continuar", Toast.LENGTH_LONG).show();
            Intent settingsIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(settingsIntent);
        } else {

            Toast.makeText(this, "Obteniendo ubicación...", Toast.LENGTH_SHORT).show();

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return; //
            }

            locationTimeoutRunnable = new Runnable() {
                @Override
                public void run() {
                    locationManager.removeUpdates(MainActivity.this);
                    Toast.makeText(MainActivity.this, "No se pudo obtener ubicación (timeout). Revisa tu señal GPS e inténtalo de nuevo.", Toast.LENGTH_LONG).show();
                }
            };
            locationTimeoutHandler.postDelayed(locationTimeoutRunnable, LOCATION_TIMEOUT_MS);

            if (isGpsEnabled) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            } else if (isNetworkEnabled) {
                // Fallback a la red si el GPS no está
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
            }
        }
    }

    private void obtenerDireccion(double lat, double lon) {
        try {

            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1); // Pide 1 resultado

            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);

                String direccionCompleta = address.getAddressLine(0);

                tvDireccion.setText("Dirección: " + direccionCompleta);

            } else {

                tvDireccion.setText("Dirección: No encontrada");
            }

        } catch (IOException e) {

            tvDireccion.setText("Dirección: Error al obtener");
            Log.e("Geocoder", "Error al obtener la dirección", e);
        }
    }



    @Override
    public void onLocationChanged(@NonNull Location location) {

        if (locationTimeoutRunnable != null) {
            locationTimeoutHandler.removeCallbacks(locationTimeoutRunnable);
        }

        locationManager.removeUpdates(this);

        String nombre = editTextNombre.getText().toString();
        double lat = location.getLatitude();
        double lon = location.getLongitude();

        // Actualizamos Latitud y Longitud
        tvLatitud.setText(String.format(Locale.US, "Latitud: %.6f", lat));
        tvLongitud.setText(String.format(Locale.US, "Longitud: %.6f", lon));

        obtenerDireccion(lat, lon);

        saveDataToFirebase(nombre, lat, lon);
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {

        if (locationTimeoutRunnable != null) {
            locationTimeoutHandler.removeCallbacks(locationTimeoutRunnable);
        }

        locationManager.removeUpdates(this);

        Toast.makeText(this, "La Ubicación fue desactivada. Inténtalo de nuevo.", Toast.LENGTH_SHORT).show();
        tvDireccion.setText("Dirección: Timeout (sin señal GPS)");

    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }


    private void saveDataToFirebase(String nombre, double lat, double lon) {
        Map<String, Object> ayudaData = new HashMap<>();
        ayudaData.put("nombre", nombre);
        ayudaData.put("lat", lat);
        ayudaData.put("lon", lon);
        ayudaData.put("timestamp", FieldValue.serverTimestamp());

        db.collection("ayudas")
                .add(ayudaData)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "¡Alerta de ayuda enviada con éxito!", Toast.LENGTH_LONG).show();
                    editTextNombre.setText("");
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error al enviar los datos: " + e.getMessage() + "intentelo nuevamente.", Toast.LENGTH_LONG).show();
                });
    }
}